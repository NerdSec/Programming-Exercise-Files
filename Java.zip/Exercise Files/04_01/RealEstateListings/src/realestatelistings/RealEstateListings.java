/*
 * This program is setup to create instances of the House class 
 * for a real estate company.  
 */
package realestatelistings;

/**
 *
 * @author Peggy Fisher
 */
public class RealEstateListings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
