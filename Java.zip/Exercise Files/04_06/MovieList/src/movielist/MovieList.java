/*
 * This program is for the challenge on creating classes
 */
package movielist;

/**
 *
 * @author Peggy Fisher
 */
public class MovieList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
